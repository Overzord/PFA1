package Login.authentification.authentification.Dao;

import Login.authentification.authentification.model.Role;
import Login.authentification.authentification.model.RoleName;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface RoleDao extends JpaRepository<Role,Long> {
    Optional<Role> findByName(RoleName roleName);
}
