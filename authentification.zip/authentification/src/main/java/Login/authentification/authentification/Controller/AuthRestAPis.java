package Login.authentification.authentification.Controller;

import Login.authentification.authentification.Payload.Request.LoginRequest;
import Login.authentification.authentification.Payload.Request.SignupRequest;
import Login.authentification.authentification.Payload.response.JwtResponse;
import Login.authentification.authentification.Payload.response.ResponseMessage;
import Login.authentification.authentification.respository.RoleRepository;
import Login.authentification.authentification.respository.UserRepository;
import Login.authentification.authentification.model.Role;
import Login.authentification.authentification.model.RoleName;
import Login.authentification.authentification.model.Utilisateur;
import Login.authentification.authentification.security.jwt.JwtUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.HashSet;
import java.util.Set;

@CrossOrigin(origins = "*" ,maxAge = 3600)
@RestController
@RequestMapping("/api/auth")
public class AuthRestAPis<roles> {
    @Autowired
    AuthenticationManager authenticationManager;

    @Autowired
    UserRepository userRepository;

    @Autowired
    RoleRepository roleRepository;

    @Autowired
    PasswordEncoder encoder;

    @Autowired
    JwtUtils jwtUtils;

    @PostMapping("/signin")
    public ResponseEntity<?> authenticateUser(@Valid @RequestBody LoginRequest loginRequest) {

        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(loginRequest.getUsername(), loginRequest.getPassword()));

        SecurityContextHolder.getContext().setAuthentication(authentication);

        String jwt = jwtUtils.generateJwtToken(authentication);
        UserDetails userDetails = (UserDetails) authentication.getPrincipal();

        return ResponseEntity.ok(new JwtResponse(jwt, userDetails.getUsername(), userDetails.getAuthorities()));
    }



    @PostMapping("/signup")
    public ResponseEntity<?> registerUser(@Valid @RequestBody SignupRequest signUpRequest) {
        if (userRepository.existsByUsername(signUpRequest.getUsername())) {
            return new ResponseEntity<>(new ResponseMessage("Fail -> Username is already taken!"),
                    HttpStatus.BAD_REQUEST);
        }

        if (userRepository.existsByEmail(signUpRequest.getEmail())) {
            return new ResponseEntity<>(new ResponseMessage("Fail -> Email is already in use!"),
                    HttpStatus.BAD_REQUEST);
        }

        // Creating user's account
        Utilisateur user = new Utilisateur(signUpRequest.getName(), signUpRequest.getUsername(), signUpRequest.getEmail(),
                encoder.encode(signUpRequest.getPassword()));

        Set<String> strRoles = signUpRequest.getRole();
        Set<Role> roles = new HashSet<>();
        for (String role : strRoles) {
            switch (role) {
                case "administrateur":
                    Role pmRole = roleRepository.findByName(RoleName.ROLE_ADMINISTRATEUR)
                            .orElseThrow(() -> new RuntimeException("Fail! -> Cause: ADMINISTRATEUR Role not find."));
                    roles.add(pmRole);

                    break;
                case "root":
                Role adminRole = roleRepository.findByName(RoleName.ROLE_ROOT)
                        .orElseThrow(() -> new RuntimeException(("Error : Role is not found")));
                roles.add(adminRole);
                break;

                case "agent":
                    Role agentRole = roleRepository.findByName(RoleName.ROLE_AGENT)
                            .orElseThrow(() -> new RuntimeException(" Error : Role is not found"));
                    break;

                case "rh":
                    Role rhRole = roleRepository.findByName(RoleName.ROLE_RH)
                            .orElseThrow(() -> new RuntimeException("Error : Role is not found"));
                    break;
                default:
                    Role userRole = roleRepository.findByName(RoleName.ROLE_RH)
                            .orElseThrow(() -> new RuntimeException("Error : Role is not found"));
                    roles.add(userRole);
            }
        }

        user.setRoles(roles);
        userRepository.save(user);

        return ResponseEntity.ok(new ResponseMessage("User registered successfully"));


    }
}
