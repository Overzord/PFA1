package Login.authentification.authentification.security;

import Login.authentification.authentification.security.jwt.AuthEntryPointJwt;
import Login.authentification.authentification.security.jwt.AuthTokenFilter;
import Login.authentification.authentification.security.services.UserDetailsServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.authentication.configurers.userdetails.DaoAuthenticationConfigurer;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(//securedEnabled =true,
                            //jsr250Enables=true,
                            prePostEnabled = true)
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
    @Autowired
    UserDetailsServiceImpl userDetailsService;

    @Autowired
    private AuthEntryPointJwt unauthorizedHandler;

    @Bean
    public AuthTokenFilter authenticationJwtTokenFilter(){
        return new AuthTokenFilter();

    }
    @Override
    public void configure(AuthenticationManagerBuilder authenticationManagerBuilder) throws Exception{
        authenticationManagerBuilder
                .userDetailsService(userDetailsService)
                .passwordEncoder(passwordEncoder());
    }

    @Bean
    @Override
    public AuthenticationManager authenticationManagerBean() throws Exception{
        return super.authenticationManagerBean();
    }
    @Bean
    public PasswordEncoder passwordEncoder(){
        return new BCryptPasswordEncoder();
    }
    @Override
    protected void configure(HttpSecurity http) throws Exception{
        http.cors().and().csrf().disable().authorizeRequests()
                .antMatchers("/file/**").permitAll()
                .antMatchers("/credit/**").access("hasRole('ROLE_RH')or hasRole('ROLE_AGENT')or hasRole('ROLE_ROOT')")
                .antMatchers("/prospet/**").access("hasRole('ROLE_RH')or hasRole('ROLE_ROOT')or hasRole('ROLE_AGENT')")
                .antMatchers("/utilisateur/**").access("hasRole('ROLE_RH')or hasRole('ROLE_AGENT')or hasRole('ROLE_ROOT')or hasRole('ROLE_ADMINISTRATEUR')")
                .antMatchers("/auth/signup").access("hasRole('ROLE_RH') ")
                .antMatchers("/parametres/*/all*").access("hasRole('ROLE_CHEF_SERVICE') or hasRole('ROLE_RH') or hasRole('ROLE_EMPLOYE') or hasRole('ROLE_ADMINISTRATEUR')")
                .antMatchers("/parametres/**").access("hasRole('ROLE_ADMINISTRATEUR')")
                .antMatchers("/auth/signin").permitAll()
                .and()
                .exceptionHandling().authenticationEntryPoint(unauthorizedHandler).and()
                .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS).and();
        http.addFilterBefore(authenticationJwtTokenFilter(), UsernamePasswordAuthenticationFilter.class);
    }
}
