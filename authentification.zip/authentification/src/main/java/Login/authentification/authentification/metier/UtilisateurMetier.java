package Login.authentification.authentification.metier;

import Login.authentification.authentification.Payload.Request.LoginRequest;
import Login.authentification.authentification.model.Utilisateur;

import java.util.List;

public interface UtilisateurMetier {
    public Utilisateur addUser(Utilisateur utilisateur);
    public void updateUser(Utilisateur utilisateur);
    public Utilisateur getUserById(Long id);
    public Utilisateur getCurrentUser();
    public Utilisateur getUser(String username);
    public List<Utilisateur> allUsers();
    public boolean updateMdp(LoginRequest lf);


    void addRole(String role, Long CollabId);
}
