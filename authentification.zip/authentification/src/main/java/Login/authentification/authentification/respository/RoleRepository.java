package Login.authentification.authentification.respository;

import Login.authentification.authentification.model.Role;
import Login.authentification.authentification.model.RoleName;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface RoleRepository extends JpaRepository<Role,Long> {
    Optional<Role> findByName(RoleName name);
}
