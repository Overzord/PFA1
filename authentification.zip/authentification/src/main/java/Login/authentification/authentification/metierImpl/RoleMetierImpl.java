package Login.authentification.authentification.metierImpl;

import Login.authentification.authentification.Dao.RoleDao;
import Login.authentification.authentification.metier.RoleMetier;
import Login.authentification.authentification.model.Role;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class RoleMetierImpl implements RoleMetier {
    @Autowired
    private RoleDao dao;
    @Override
    public Role addRole(Role roles) {
        return this.dao.save(roles) ;
    }

    @Override
    public void updateRole(Role roles) {
        this.dao.save(roles);
    }

    @Override
    public Role getRoleById(Long id) {
        return this.dao.findById(id).get();
    }

    @Override
    public List<Role> allRole() {
        return this.dao.findAll();
    }
}
