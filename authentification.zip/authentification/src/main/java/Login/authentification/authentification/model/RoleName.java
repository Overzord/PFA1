package Login.authentification.authentification.model;

public enum RoleName {

    ROLE_RH,
    ROLE_AGENT,
    ROLE_ROOT,
    ROLE_ADMINISTRATEUR
}
