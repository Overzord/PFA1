package Login.authentification.authentification.metierImpl;

import Login.authentification.authentification.Dao.RoleDao;
import Login.authentification.authentification.Dao.UtilisateurDao;
import Login.authentification.authentification.Payload.Request.LoginRequest;
import Login.authentification.authentification.metier.UtilisateurMetier;
import Login.authentification.authentification.model.Role;
import Login.authentification.authentification.model.RoleName;
import Login.authentification.authentification.model.Utilisateur;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.List;
import java.util.Optional;

public class UtilisateurMetierImpl implements UtilisateurMetier {
    @Autowired
    PasswordEncoder encoder;
    @Autowired
    private UtilisateurDao dao;
    @Autowired
    private RoleDao rd;

    @Override
    public Utilisateur getUserById(Long id) {
        return this.dao.findById(id).get();
    }

    @Override
    public Utilisateur addUser(Utilisateur u) {
        return this.dao.save(u);
    }

    @Override
    public void updateUser(Utilisateur u) {
        this.dao.save(u);
    }

    @Override
    public List<Utilisateur> allUsers() {
        return this.dao.findAll();
    }

    @Override
    public Utilisateur getCurrentUser() {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String username = "";
        if (principal instanceof UserDetails) {
            username = ((UserDetails) principal).getUsername();
        } else {
            username = principal.toString();
        }
        Optional<Utilisateur> users = this.dao.findByUsername(username);
        if (users.isPresent()) {
            return users.get();
        } else {
            return null;
        }
    }

    @Override
    public Utilisateur getUser(String username) {
        Optional<Utilisateur> users = this.dao.findByUsername(username);
        if (users.isPresent()) {
            return users.get();
        } else {
            return null;
        }
    }

    @Override
    public boolean updateMdp(LoginRequest lf) {
        Utilisateur u = this.dao.findByUsername(lf.getUsername()).get();
        u.setPassword(encoder.encode(lf.getPassword()));
        dao.save(u);
        return true;
    }


    @Override
    public void addRole(String role, Long CollabId) {
        Role r = new Role();
        switch (role) {
            case "Administrateur":
                r = rd.findByName(RoleName.ROLE_ADMINISTRATEUR).get();
                break;
            case "Agent":
                r = rd.findByName(RoleName.ROLE_AGENT).get();
                break;
            case "Responsable RH":
                r = rd.findByName(RoleName.ROLE_RH).get();
                break;
        }


    }


    }


