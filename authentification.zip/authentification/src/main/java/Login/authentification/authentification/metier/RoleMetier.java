package Login.authentification.authentification.metier;

import Login.authentification.authentification.model.Role;

import java.util.List;

public interface RoleMetier {
    public Role addRole(Role roles);
    public void updateRole(Role roles);
    public Role getRoleById(Long id);
    public List<Role> allRole();
}
