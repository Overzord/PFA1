package com.EmailSend.model;



import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.NotNull;

public class Contact {

    private String name;

    private String email;

    private String subject;

    private String comment;

    private MultipartFile attachement;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public MultipartFile getAttachement() {
        return attachement;
    }

    public void setAttachement(MultipartFile attachement) {
        this.attachement = attachement;
    }
    @Override
    public String toString(){
        return "Contact[name="+name+",email="+email+",subject="+subject+",comment="+comment+",attachement="+attachement+",getName()="
                +getName()+",getEmail()="+getEmail()+",getSubject()="+getSubject()+",getComment()="+getComment()+",getAttachement()="+
                getAttachement()+",getClass()="+getClass()+",hashCode()="+hashCode()+",toString()="+super.toString()+"]";
    }
}

