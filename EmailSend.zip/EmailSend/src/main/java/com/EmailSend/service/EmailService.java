package com.EmailSend.service;

import com.EmailSend.model.Contact;
import org.springframework.web.multipart.MultipartFile;

import javax.mail.MessagingException;

public interface EmailService {
    public void sendSimpleEmail(Contact contact)throws MessagingException;
    public void sendAttachementEmail(Contact contact, MultipartFile file)throws MessagingException;
}
