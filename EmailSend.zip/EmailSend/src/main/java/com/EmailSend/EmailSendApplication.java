package com.EmailSend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = {"com.EmailSend.controller","com.EmailSend.service"})
public class EmailSendApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmailSendApplication.class, args);
	}

}
