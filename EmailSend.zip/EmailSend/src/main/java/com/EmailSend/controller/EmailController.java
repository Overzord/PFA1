package com.EmailSend.controller;

import com.EmailSend.model.Contact;
import com.EmailSend.service.EmailService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import javax.mail.MessagingException;
import javax.validation.Valid;

@Controller
@RequestMapping("/email-app")
public class EmailController {
    private static Logger log = LoggerFactory.getLogger(EmailController.class);

    @Autowired(required = true)
    private EmailService emailService;

    @GetMapping(value = {"/", "/home", "/index"})
    public String homePage(){
        log.info("Showing homePage....");
        return "index";
    }
    @GetMapping("/success")
    public String successPage(){
        log.info("Showing successPage...");
        return "success";
    }
    @GetMapping("/text-email")
    public ModelAndView textEmail(Contact contact){
        ModelAndView mav =new ModelAndView("text-email");
        mav.addObject("textEmail",contact);
        log.info("Showing Text-Based Email form...");
        return mav;
    }
    @GetMapping("/attachement-email")
    public ModelAndView attachementEmail(Contact contact){
        ModelAndView mav= new ModelAndView("attachement-email");
        mav.addObject("attachementEmail",contact);
        log.info("Showing Attachement-Based Email Form....");
        return mav;
    }
    @PostMapping("/sendTextEmail")
    public ModelAndView sendSimpleEmail(@Valid @ModelAttribute("textEmail") Contact contact, BindingResult br)
        throws MessagingException {
        try {
            ModelAndView nav = new ModelAndView("success");
            log.info("Spring Boot - Sending Text Email ...");
            if (br.hasErrors()) {
                log.error("Something gone wrong");
                return new ModelAndView("text-email");
            }else{
                log.info(contact.getName() + " " + contact.getEmail() + " " + contact.getSubject()
                + " " + contact.getComment());
                contact.setName(contact.getName());
                contact.setEmail(contact.getEmail());
                contact.setSubject(contact.getSubject());
                contact.setComment(contact.getComment());
                nav.addObject("name",contact.getName());
                log.info("Sending Text Email ...");
                emailService.sendSimpleEmail(contact);
                log.info("Done ...");
            }
            return nav;

        }catch (Exception e){
            log.error(e.getMessage());
            return new ModelAndView("text-email");
        }
    }

    @SuppressWarnings("unlikely-arf-type")
    @RequestMapping(value = "/sendAttachementEmail",consumes = "multipart/form-data",method = RequestMethod.POST)
    public ModelAndView sendEmailWithAttachement(@Valid @ModelAttribute("attachementEmail")Contact contact, BindingResult br , final @RequestParam("attachement")MultipartFile attachFile)
        throws MessagingException{
        try{
            ModelAndView nav =new ModelAndView("success");
            log.info("Spring Boot - Sending Attachement Email ...");
            if(br.hasErrors()){
                log.error("Something gone wrong ...");
                return new ModelAndView("attachement-email");

            }else{
                //reads form input
                final String email = contact.getEmail();
                final String name = contact.getName();
                final String subject = contact.getSubject();
                final String comment = contact.getComment();

                log.info(name + " " + email + " " + subject +" " + comment );

                if((attachFile != null) && (attachFile.getSize() > 0)&& (!attachFile.equals(""))){
                    log.info("FileName=====" + attachFile.getOriginalFilename());

                }else{
                    log.info("FileName====" + attachFile.getOriginalFilename() + " " + attachFile);

                }
                contact.setName(name);
                contact.setEmail(email);
                contact.setSubject(subject);
                contact.setComment(comment);
                nav.addObject("name",contact.getName());
                emailService.sendAttachementEmail(contact,attachFile);
                log.info("Done ...");
                return nav;
            }
        }catch (Exception e){
            log.error(e.getMessage());
            return new ModelAndView("attachement-email");
        }
    }

}
